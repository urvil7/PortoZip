from django.apps import AppConfig


class MenConfig(AppConfig):
    name = 'Men'
