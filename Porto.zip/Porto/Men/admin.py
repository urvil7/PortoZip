from django.contrib import admin
from .models import Men_Item
# Register your models here.
admin.site.register(Men_Item)
